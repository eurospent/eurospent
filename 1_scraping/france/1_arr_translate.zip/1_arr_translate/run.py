import os
import rdflib
import csv
import unicodecsv as csv

arr = dict()
can = dict()
com = dict()

for file in [f for f in os.listdir('.') if os.path.isfile(f) and f.endswith('rdf')]:
	g = rdflib.Graph()
	g.parse(file)

	for s, p, o in g:
		key = s.replace('http://rdf.insee.fr/geo/2011/', '')
		type = p.replace('http://rdf.insee.fr/geo/', '').replace('http://www.w3.org/1999/02/22-rdf-syntax-ns#', '')
		object = o.replace('http://rdf.insee.fr/geo/', '').replace('2011/', '')

		if type not in ('nom','type','code_canton','subdivision','code_arrondissement','code_commune'):
			continue

		if key.startswith('ARR_'):
			arr.setdefault(key, {'code': None, 'name': None, 'can': set(), 'com': set()})
			if type == u'code_arrondissement': arr[key]['code'] = object
			if type == u'nom': arr[key]['name'] = object
			if type == u'subdivision' and object.startswith('COM'): arr[key]['com'].add(object)
			if type == u'subdivision' and object.startswith('CAN'): arr[key]['can'].add(object)

		if key.startswith('COM_'):
			com.setdefault(key, {'code': None, 'name': None})
			if type == u'code_commune': com[key]['code'] = object
			if type == u'nom': com[key]['name'] = object

		if key.startswith('CAN_'):
			can.setdefault(key, {'code': None, 'name': None})
			if type == u'code_canton': can[key]['code'] = object
			if type == u'nom': can[key]['name'] = object

com_file = open('com.csv','w')
com_writer = csv.writer(com_file, delimiter=',')
can_file = open('can.csv','w')
can_writer = csv.writer(can_file, delimiter=',')

for a in arr.values():
	for c in a['com']:
		com_writer.writerow([a['code'], a['name'], com[c]['code'], com[c]['name']])
	for c in a['can']:
		can_writer.writerow([a['code'], a['name'], can[c]['code'], can[c]['name']])
