import os
import rdflib
import csv
import unicodecsv as csv

can = dict()
com = dict()

for file in [f for f in os.listdir('.') if os.path.isfile(f) and f.endswith('rdf')]:
	g = rdflib.Graph()
	g.parse(file)
	for s, p, o in g:
		key = s.replace('http://rdf.insee.fr/geo/2011/', '')
		type = p.replace('http://rdf.insee.fr/geo/', '')
		object = o.replace('http://rdf.insee.fr/geo/', '').replace('2011/', '')

		if type not in ('nom','code_canton','subdivision','code_INSEE','code_commune', 'fraction_cantonale'):
			continue

		if key.startswith('CAN_'):
			can.setdefault(key, {'code': None, 'name': None, 'com': set(), 'frac_com': set()})
			if type == u'code_canton': can[key]['code'] = object
			if type == u'code_INSEE': can[key]['code'] = object
			if type == u'nom': can[key]['name'] = object
			if type == u'subdivision': can[key]['com'].add(object)
			if type == u'fraction_cantonale': can[key]['frac_com'].add(object)

		if key.startswith('COM_'):
			com.setdefault(key, {'code': None, 'name': None})
			if type == u'code_commune': com[key]['code'] = object
			if type == u'nom': com[key]['name'] = object

	print file

com_file = open('com.csv','w')
com_writer = csv.writer(com_file, delimiter=',')
for ca in can.values():
	for co in ca['com']:
		com_writer.writerow([ca['code'], ca['name'] or com[co]['name'], com[co]['code'], com[co]['name'], 'com'])
	for co in ca['frac_com']:
		com_writer.writerow([ca['code'], ca['name'], com[co]['code'], com[co]['name'], 'frac_com'])
